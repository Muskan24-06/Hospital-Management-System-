package hospital.management.system;

public class array12 {
    public static void main(String[] args) {
        
    }
}
